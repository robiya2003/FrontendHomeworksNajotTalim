const { getMin } = require("../../control-flow/src");

/**
 *
 * @param str: {String}
 * @param symbolsCount: {Number}
 * @returns {String}
 */
module.exports.backToFront = function backToFront(str, symbolsCount) {
    if(symbolsCount>str.length)
         return str;
    else if(str.length==symbolsCount)
         return str+str+str;
    else if(symbolsCount==1)
        {return str[str.length-1]+str+str[str.length-1]}
    let a=str.length;
    let b=a-symbolsCount;
    let word=str.slice(b);


   
    
    return word+str+word;
    
};

/**
 *
 * @param z: {Number}
 * @param x: {Number}
 * @param y: {Number}
 * @returns {Number}
 */
module.exports.nearest = function nearest(z, x, y) {
  
    let a=1000;
    let arr=[x,y,z];
    for (let i = 0; i < arr.length; i++) {
        if(a>arr[i]) a=arr[i];
        
    }
    return a;

};

/**
 *
 * @param arr: {Array}
 * @returns {Array}
 */
module.exports.removeDuplicate = function removeDuplicate(arr) {
    let newarr=[];
    arr.forEach(i => {
        if(!newarr.includes(i)) newarr.push(i);
    });
    return newarr;
};
